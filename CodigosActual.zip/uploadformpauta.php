<?php
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->dirroot . '/course/lib.php');
class mod_emarking_upload_form extends moodleform {
	public function definition() {
		$mform = $this->_form;
		$instance = $this->_customdata;
		// Header.
		$mform->addElement('header', 'digitizedfile', 'Upload Pauta as PDF file');
		// File picker for the digitized answers.
		$mform->addElement('filepicker', 'assignment_file', 'PDF file', null,
				$instance ['options']);
		$mform->addRule('assignment_file', get_string('filerequiredzip', 'mod_emarking'), 'required', null, 'client');
		$mform->setType('assignment_file', PARAM_FILE);
		// A merge to indicate if the new files should be merged with any previous submissions.
		$mform->addElement('hidden', 'merge', false);
		$mform->setType('merge', PARAM_BOOL);
		// The course module id.
		$mform->addElement('hidden', 'id', $instance ['coursemoduleid']);
		$mform->setType('id', PARAM_INT);
		// The activity id.
		$mform->addElement('hidden', 'emarkingid', $instance ['emarkingid']);
		$mform->setType('emarkingid', PARAM_INT);
		// Action buttons.
		$this->add_action_buttons(true, get_string('processtitle', 'mod_emarking'));
	}
}