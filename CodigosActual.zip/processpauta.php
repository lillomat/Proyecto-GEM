<?php
define('NO_OUTPUT_BUFFERING', true);
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/config.php');
require_once("$CFG->dirroot/lib/weblib.php");
require_once($CFG->dirroot . '/repository/lib.php');
require_once($CFG->dirroot . '/mod/emarking/locallib.php');
require_once($CFG->dirroot . '/mod/emarking/print/locallib.php');
global $DB, $CFG, $USER;
// Obtains basic data from cm id.
list($cm, $emarking, $course, $context) = emarking_get_cm_course_instance();
$emarkingid = required_param('emarkingid', PARAM_INT);
$fileid = required_param('file', PARAM_ALPHANUM);
$merge = required_param('merge', PARAM_BOOL);
// Validate user is logged in and is not guest.
require_login($course->id);
if (isguestuser()) {
	die();
}
$url = new moodle_url('/mod/emarking/print/processpauta.php',
		array(
				'emarkingid' => $emarking->id,
				'file' => $fileid,
				'merge' => $merge));
		$urlassignment = new moodle_url('/mod/emarking/view.php', array(
				'id' => $cm->id));
		$PAGE->set_pagelayout('incourse');
		$PAGE->set_popup_notification_allowed(false);
		$PAGE->set_url($url);
		$PAGE->set_context($context);
		$PAGE->set_course($course);
		$PAGE->set_cm($cm);
		$PAGE->set_title(get_string('emarking', 'mod_emarking'));
		$PAGE->set_heading($course->fullname);
		$PAGE->navbar->add(get_string('uploadanswers', 'mod_emarking'));
		echo $OUTPUT->header();
		echo $OUTPUT->heading('Analizing Uploaded Pauta');
		// Setup de directorios temporales.
		$tempdir = emarking_get_temp_dir_path($emarking->id);
		emarking_initialize_directory($tempdir, true);
		$pdffile = emarking_get_path_from_hash($tempdir, $fileid);
		// Process documents and obtain results.
		$status = emarking_upload_pauta($emarking, $pdffile, $course,
				$cm);
		echo "<h6>The File has been uploaded correctly.</h6>";
		echo "<br>";
		echo "Uploaded File:";
		echo "<br>";
		?>
		<?php
		$fs = get_file_storage();
		if($fs->file_exists($context->id, 'mod_emarking', 'pauta', $emarking->id, '/', 'pauta_'.$emarking->id.'.pdf') == true){
			echo "<img src='http://localhost/moodle/theme/image.php/clean/core/1463947144/f/pdf-24' class='iconlarge activityicon' alt=' ' role='presentation' id='yui_3_17_2_1_1464808445248_1726'>";
			echo "<a href='http://localhost/moodle/pluginfile.php/$context->id/mod_emarking/pauta/$emarking->id/pauta_$emarking->id.pdf'>Pauta</a>";
		}
		echo "<br><br>";
				$continueurl = new moodle_url('/mod/emarking/view.php',
						array(
								'id' => $cm->id,
								'scan' => $emarking->type != EMARKING_TYPE_MARKER_TRAINING));
						echo $OUTPUT->continue_button($continueurl);
						echo $OUTPUT->footer();